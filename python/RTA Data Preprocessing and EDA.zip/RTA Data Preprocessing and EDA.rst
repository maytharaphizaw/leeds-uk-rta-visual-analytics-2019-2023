.. code:: ipython3

    # === Imports ===
    import os
    import pandas as pd
    import numpy as np
    from datetime import datetime
    import matplotlib.pyplot as plt
    import seaborn as sns
    import glob
    from geopy.distance import geodesic
    


::


      Cell In[114], line 9
        install geopy
                ^
    SyntaxError: invalid syntax
    


.. code:: ipython3

    # Data Look up and Leeds filtering
    
    import pandas as pd
    
    # base_path directory
    base_path = r"C:\Users\mayth\OneDrive - Leeds Beckett University\MS Data Science Modules\Dissertation\RTA Dataset\\"
    
    # define look_up table
    lookup_file = base_path + "dft-road-casualty-statistics-road-safety-open-dataset-data-guide-2024.xlsx"
    
    # define the paths for the main datasets (collision, vehicle, and casualty)
    files = {
        "collision": base_path + "dft-road-casualty-statistics-collision-last-5-years.csv",
        "vehicle": base_path + "dft-road-casualty-statistics-vehicle-last-5-years.csv",
        "casualty": base_path + "dft-road-casualty-statistics-casualty-last-5-years.csv"
    }
    
    # load the datasets from CSV into pandas dataframes
    collision_df = pd.read_csv(files["collision"], low_memory=False)
    vehicle_df = pd.read_csv(files["vehicle"], low_memory=False)
    casualty_df = pd.read_csv(files["casualty"], low_memory=False)
    
    # filter the collision data to only include rows where the district is Leeds
    # Leeds district code is E08000035
    leeds_collision_df = collision_df[collision_df['local_authority_ons_district'] == "E08000035"]
    
    # accident index from main Leeds collision data
    leeds_accidents = leeds_collision_df['accident_index'].unique()
    
    # filter the vehicle and casualty datasets using the Leeds accident index
    leeds_vehicle_df = vehicle_df[vehicle_df['accident_index'].isin(leeds_accidents)]
    leeds_casualty_df = casualty_df[casualty_df['accident_index'].isin(leeds_accidents)]
    
    # function to replace coded values with labels (look_up table)
    def apply_lookups(df, dataset_name, lookup_excel):
        # Load the lookup table
        lookup_df = pd.read_excel(lookup_excel, sheet_name="2024_code_list")
    
        # filter to only the relevant codes for this dataset
        lookup_filtered = lookup_df[
            (lookup_df['table'] == dataset_name) &
            lookup_df['label'].notnull() &
            lookup_df['code/format'].notnull()
        ][['field name', 'code/format', 'label']]
    
        # apply the mapping
        for field in lookup_filtered['field name'].unique():
            if field in df.columns:
                code_map = lookup_filtered[lookup_filtered['field name'] == field].set_index('code/format')['label'].to_dict()
                # Use .loc to safely update the column
                df.loc[:, field] = df[field].map(code_map)
    
        return df
    
    
    # apply the lookups to clean the Leeds datasets
    leeds_collision_after_lookup = apply_lookups(leeds_collision_df, "accident", lookup_file)
    leeds_vehicle_after_lookup = apply_lookups(leeds_vehicle_df, "vehicle", lookup_file)
    leeds_casualty_after_lookup = apply_lookups(leeds_casualty_df, "casualty", lookup_file)
    
    # save the cleaned Leeds datasets to new CSV files
    leeds_collision_after_lookup.to_csv(base_path + "leeds_collision_after_lookup.csv", index=False)
    leeds_vehicle_after_lookup.to_csv(base_path + "leeds_vehicle_after_lookup.csv", index=False)
    leeds_casualty_after_lookup.to_csv(base_path + "leeds_casualty_after_lookup.csv", index=False)
    
    # successful message
    print("All Leeds datasets filtered by local authority code and cleaned successfully.")
    

.. code:: ipython3

    # Leeds Collision Data Summary
    print("Leeds Collision Data (Looked up)")
    print(leeds_collision_after_lookup.head(), "\n")
    print("Shape:", leeds_collision_after_lookup.shape)
    print("Columns:", leeds_collision_after_lookup.columns.tolist())
    print("Missing values:\n", leeds_collision_after_lookup.isnull().sum(), "\n")
    
    # Leeds Vehicle Data Summary
    print("Leeds Vehicle Data (Looked up)")
    print(leeds_vehicle_after_lookup.head(), "\n")
    print("Shape:", leeds_vehicle_after_lookup.shape)
    print("Columns:", leeds_vehicle_after_lookup.columns.tolist())
    print("Missing values:\n", leeds_vehicle_after_lookup.isnull().sum(), "\n")
    
    # Leeds Casualty Data Summary
    print("Leeds Casualty Data (Looked up)")
    print(leeds_casualty_after_lookup.head(), "\n")
    print("Shape:", leeds_casualty_after_lookup.shape)
    print("Columns:", leeds_casualty_after_lookup.columns.tolist())
    print("Missing values:\n", leeds_casualty_after_lookup.isnull().sum(), "\n")
    


.. parsed-literal::

    Leeds Collision Data (Looked up)
          accident_index  accident_year accident_reference  location_easting_osgr  \
    41052  2019131901350           2019          131901350               443576.0   
    41053  20191358F1730           2019          1358F1730               436147.0   
    41055  2019136111190           2019          136111190               435904.0   
    41057  2019136111674           2019          136111674               423194.0   
    41058  2019136111836           2019          136111836               429149.0   
    
           location_northing_osgr  longitude   latitude    police_force  \
    41052                438198.0  -1.339288  53.838231  West Yorkshire   
    41053                434957.0  -1.452556  53.809670  West Yorkshire   
    41055                425850.0  -1.457300  53.727837  West Yorkshire   
    41057                438111.0  -1.649019  53.838752  West Yorkshire   
    41058                431736.0  -1.559127  53.781158  West Yorkshire   
    
          accident_severity  number_of_vehicles  ...       light_conditions  \
    41052           Serious                   4  ...               Daylight   
    41053            Slight                   2  ...               Daylight   
    41055            Slight                   2  ...               Daylight   
    41057            Slight                   1  ...               Daylight   
    41058           Serious                   2  ...  Darkness - lights lit   
    
              weather_conditions road_surface_conditions  \
    41052  Raining no high winds             Wet or damp   
    41053     Fine no high winds                     Dry   
    41055     Fine no high winds                     Dry   
    41057     Fine no high winds                     Dry   
    41058     Fine no high winds                     Dry   
    
          special_conditions_at_site carriageway_hazards urban_or_rural_area  \
    41052                        NaN                 NaN               Rural   
    41053                        NaN                 NaN               Urban   
    41055                        NaN                 NaN               Rural   
    41057                        NaN                 NaN               Urban   
    41058                        NaN                 NaN               Urban   
    
          did_police_officer_attend_scene_of_accident  \
    41052                                         Yes   
    41053                                          No   
    41055                                         Yes   
    41057                                         Yes   
    41058                                         Yes   
    
                                     trunk_road_flag lsoa_of_accident_location  \
    41052  Trunk (Roads managed by Highways England)                 E01011309   
    41053                                  Non-trunk                 E01011666   
    41055                                  Non-trunk                 E01011636   
    41057                                  Non-trunk                 E01011461   
    41058                                  Non-trunk                 E01011366   
    
          enhanced_severity_collision  
    41052                          -1  
    41053                          -1  
    41055                          -1  
    41057                          -1  
    41058                          -1  
    
    [5 rows x 37 columns] 
    
    Shape: (6900, 37)
    Columns: ['accident_index', 'accident_year', 'accident_reference', 'location_easting_osgr', 'location_northing_osgr', 'longitude', 'latitude', 'police_force', 'accident_severity', 'number_of_vehicles', 'number_of_casualties', 'date', 'day_of_week', 'time', 'local_authority_district', 'local_authority_ons_district', 'local_authority_highway', 'first_road_class', 'first_road_number', 'road_type', 'speed_limit', 'junction_detail', 'junction_control', 'second_road_class', 'second_road_number', 'pedestrian_crossing_human_control', 'pedestrian_crossing_physical_facilities', 'light_conditions', 'weather_conditions', 'road_surface_conditions', 'special_conditions_at_site', 'carriageway_hazards', 'urban_or_rural_area', 'did_police_officer_attend_scene_of_accident', 'trunk_road_flag', 'lsoa_of_accident_location', 'enhanced_severity_collision']
    Missing values:
     accident_index                                    0
    accident_year                                     0
    accident_reference                                0
    location_easting_osgr                             0
    location_northing_osgr                            0
    longitude                                         0
    latitude                                          0
    police_force                                      0
    accident_severity                                 0
    number_of_vehicles                                0
    number_of_casualties                              0
    date                                              0
    day_of_week                                       0
    time                                              0
    local_authority_district                          0
    local_authority_ons_district                      0
    local_authority_highway                           0
    first_road_class                                  0
    first_road_number                              3160
    road_type                                         0
    speed_limit                                    6900
    junction_detail                                   0
    junction_control                                  0
    second_road_class                                 0
    second_road_number                             3833
    pedestrian_crossing_human_control                 0
    pedestrian_crossing_physical_facilities           0
    light_conditions                                  0
    weather_conditions                                0
    road_surface_conditions                           0
    special_conditions_at_site                     6735
    carriageway_hazards                            6750
    urban_or_rural_area                               0
    did_police_officer_attend_scene_of_accident       0
    trunk_road_flag                                   0
    lsoa_of_accident_location                         0
    enhanced_severity_collision                       0
    dtype: int64 
    
    Leeds Vehicle Data (Looked up)
          accident_index  accident_year accident_reference  vehicle_reference  \
    74565  2019131901350           2019          131901350                  1   
    74566  2019131901350           2019          131901350                  2   
    74567  2019131901350           2019          131901350                  3   
    74568  2019131901350           2019          131901350                  4   
    74569  20191358F1730           2019          1358F1730                  1   
    
                            vehicle_type towing_and_articulation  \
    74565  Goods 7.5 tonnes mgw and over     Articulated vehicle   
    74566  Goods 7.5 tonnes mgw and over     No tow/articulation   
    74567  Goods 7.5 tonnes mgw and over     Articulated vehicle   
    74568  Goods 7.5 tonnes mgw and over     Articulated vehicle   
    74569                            Car     No tow/articulation   
    
               vehicle_manoeuvre vehicle_direction_from vehicle_direction_to  \
    74565  Changing lane to left                  North                South   
    74566    Slowing or stopping                  North                South   
    74567    Slowing or stopping                  North                South   
    74568    Slowing or stopping                  North                South   
    74569      Going ahead other                  South                North   
    
                 vehicle_location_restricted_lane  ... generic_make_model  \
    74565  On main c'way - not in restricted lane  ...                NaN   
    74566  On main c'way - not in restricted lane  ...                NaN   
    74567  On main c'way - not in restricted lane  ...                NaN   
    74568  On main c'way - not in restricted lane  ...                NaN   
    74569  On main c'way - not in restricted lane  ...                NaN   
    
                      driver_imd_decile         driver_home_area_type  \
    74565             Most deprived 10%                    Urban area   
    74566          More deprived 10-20%                    Urban area   
    74567          More deprived 30-40%                    Urban area   
    74568  Data missing or out of range  Data missing or out of range   
    74569  Data missing or out of range  Data missing or out of range   
    
          lsoa_of_driver                 escooter_flag dir_from_e dir_from_n  \
    74565      E01010616  Vehicle was not an e-scooter        NaN        NaN   
    74566      E01011250  Vehicle was not an e-scooter        NaN        NaN   
    74567      E01013314  Vehicle was not an e-scooter        NaN        NaN   
    74568             -1  Vehicle was not an e-scooter        NaN        NaN   
    74569             -1  Vehicle was not an e-scooter        NaN        NaN   
    
          dir_to_e dir_to_n                            driver_distance_banding  
    74565      NaN      NaN  Collision occurred between 20.001 and 100km of...  
    74566      NaN      NaN  Collision occurred between 20.001 and 100km of...  
    74567      NaN      NaN  Collision occurred between 20.001 and 100km of...  
    74568      NaN      NaN                                                NaN  
    74569      NaN      NaN                                                NaN  
    
    [5 rows x 34 columns] 
    
    Shape: (12673, 34)
    Columns: ['accident_index', 'accident_year', 'accident_reference', 'vehicle_reference', 'vehicle_type', 'towing_and_articulation', 'vehicle_manoeuvre', 'vehicle_direction_from', 'vehicle_direction_to', 'vehicle_location_restricted_lane', 'junction_location', 'skidding_and_overturning', 'hit_object_in_carriageway', 'vehicle_leaving_carriageway', 'hit_object_off_carriageway', 'first_point_of_impact', 'vehicle_left_hand_drive', 'journey_purpose_of_driver', 'sex_of_driver', 'age_of_driver', 'age_band_of_driver', 'engine_capacity_cc', 'propulsion_code', 'age_of_vehicle', 'generic_make_model', 'driver_imd_decile', 'driver_home_area_type', 'lsoa_of_driver', 'escooter_flag', 'dir_from_e', 'dir_from_n', 'dir_to_e', 'dir_to_n', 'driver_distance_banding']
    Missing values:
     accident_index                          0
    accident_year                           0
    accident_reference                      0
    vehicle_reference                       0
    vehicle_type                            0
    towing_and_articulation                 0
    vehicle_manoeuvre                       0
    vehicle_direction_from                  0
    vehicle_direction_to                    0
    vehicle_location_restricted_lane        0
    junction_location                       0
    skidding_and_overturning            10818
    hit_object_in_carriageway           11592
    vehicle_leaving_carriageway             0
    hit_object_off_carriageway          11516
    first_point_of_impact                   0
    vehicle_left_hand_drive                 0
    journey_purpose_of_driver               0
    sex_of_driver                           0
    age_of_driver                       10648
    age_band_of_driver                      0
    engine_capacity_cc                   9850
    propulsion_code                         0
    age_of_vehicle                          0
    generic_make_model                  12673
    driver_imd_decile                       0
    driver_home_area_type                   0
    lsoa_of_driver                          0
    escooter_flag                           0
    dir_from_e                          12673
    dir_from_n                          12673
    dir_to_e                            12673
    dir_to_n                            12673
    driver_distance_banding              2509
    dtype: int64 
    
    Leeds Casualty Data (Looked up)
          accident_index  accident_year accident_reference  vehicle_reference  \
    51140  2019131901350           2019          131901350                  1   
    51141  20191358F1730           2019          1358F1730                  2   
    51142  20191358F1730           2019          1358F1730                  2   
    51143  20191358F1730           2019          1358F1730                  2   
    51144  20191358F1730           2019          1358F1730                  2   
    
           casualty_reference   casualty_class sex_of_casualty age_of_casualty  \
    51140                   1  Driver or rider            Male             NaN   
    51141                   1        Passenger          Female             NaN   
    51142                   2        Passenger            Male             NaN   
    51143                   3        Passenger          Female             NaN   
    51144                   4        Passenger            Male             NaN   
    
          age_band_of_casualty casualty_severity  ... pedestrian_movement  \
    51140              36 - 45           Serious  ...    Not a Pedestrian   
    51141               6 - 10            Slight  ...    Not a Pedestrian   
    51142               6 - 10            Slight  ...    Not a Pedestrian   
    51143              36 - 45            Slight  ...    Not a Pedestrian   
    51144                0 - 5            Slight  ...    Not a Pedestrian   
    
               car_passenger        bus_or_coach_passenger  \
    51140  Not car passenger  Not a bus or coach passenger   
    51141  Not car passenger              Seated passenger   
    51142  Not car passenger              Seated passenger   
    51143  Not car passenger              Seated passenger   
    51144  Not car passenger              Seated passenger   
    
          pedestrian_road_maintenance_worker  \
    51140                No / Not applicable   
    51141                No / Not applicable   
    51142                No / Not applicable   
    51143                No / Not applicable   
    51144                No / Not applicable   
    
                                              casualty_type  \
    51140  Goods vehicle (7.5 tonnes mgw and over) occupant   
    51141     Bus or coach occupant (17 or more pass seats)   
    51142     Bus or coach occupant (17 or more pass seats)   
    51143     Bus or coach occupant (17 or more pass seats)   
    51144     Bus or coach occupant (17 or more pass seats)   
    
          casualty_home_area_type   casualty_imd_decile lsoa_of_casualty  \
    51140              Urban area     Most deprived 10%        E01010616   
    51141              Urban area     Most deprived 10%        E01011476   
    51142              Urban area     Most deprived 10%        E01011476   
    51143              Urban area  More deprived 10-20%        E01003179   
    51144              Urban area  More deprived 10-20%        E01003179   
    
             enhanced_casualty_severity  \
    51140  Data missing or out of range   
    51141  Data missing or out of range   
    51142  Data missing or out of range   
    51143  Data missing or out of range   
    51144  Data missing or out of range   
    
                                   casualty_distance_banding  
    51140  Collision occurred between 20.001 and 100km of...  
    51141  Collision occurred between 5.001 and 10km of c...  
    51142  Collision occurred between 5.001 and 10km of c...  
    51143  Collision occurred over 100km of casualties ho...  
    51144  Collision occurred over 100km of casualties ho...  
    
    [5 rows x 21 columns] 
    
    Shape: (8883, 21)
    Columns: ['accident_index', 'accident_year', 'accident_reference', 'vehicle_reference', 'casualty_reference', 'casualty_class', 'sex_of_casualty', 'age_of_casualty', 'age_band_of_casualty', 'casualty_severity', 'pedestrian_location', 'pedestrian_movement', 'car_passenger', 'bus_or_coach_passenger', 'pedestrian_road_maintenance_worker', 'casualty_type', 'casualty_home_area_type', 'casualty_imd_decile', 'lsoa_of_casualty', 'enhanced_casualty_severity', 'casualty_distance_banding']
    Missing values:
     accident_index                           0
    accident_year                            0
    accident_reference                       0
    vehicle_reference                        0
    casualty_reference                       0
    casualty_class                           0
    sex_of_casualty                          0
    age_of_casualty                       8860
    age_band_of_casualty                     0
    casualty_severity                        0
    pedestrian_location                      0
    pedestrian_movement                      0
    car_passenger                            0
    bus_or_coach_passenger                   0
    pedestrian_road_maintenance_worker       0
    casualty_type                            0
    casualty_home_area_type                  0
    casualty_imd_decile                      0
    lsoa_of_casualty                         0
    enhanced_casualty_severity               0
    casualty_distance_banding                0
    dtype: int64 
    
    

.. code:: ipython3

    # General overview of numeric and categorical fields
    print("Leeds Collision Summary Stats:")
    print(leeds_collision_after_lookup.describe(include='all'), "\n")
    
    print("Leeds Vehicle Summary Stats:")
    print(leeds_vehicle_after_lookup.describe(include='all'), "\n")
    
    print("Leeds Casualty Summary Stats:")
    print(leeds_casualty_after_lookup.describe(include='all'), "\n")
    


.. parsed-literal::

    Leeds Collision Summary Stats:
           accident_index  accident_year accident_reference  \
    count            6900    6900.000000               6900   
    unique           6900            NaN               6900   
    top     2023132300299            NaN          132300299   
    freq                1            NaN                  1   
    mean              NaN    2021.087246                NaN   
    std               NaN       1.434742                NaN   
    min               NaN    2019.000000                NaN   
    25%               NaN    2020.000000                NaN   
    50%               NaN    2021.000000                NaN   
    75%               NaN    2022.000000                NaN   
    max               NaN    2023.000000                NaN   
    
            location_easting_osgr  location_northing_osgr    longitude  \
    count             6900.000000             6900.000000  6900.000000   
    unique                    NaN                     NaN          NaN   
    top                       NaN                     NaN          NaN   
    freq                      NaN                     NaN          NaN   
    mean            429993.609855           434291.203333    -1.546064   
    std               5110.018130             4500.992859     0.077607   
    min             414743.000000           423157.000000    -1.777214   
    25%             427154.500000           431855.250000    -1.589156   
    50%             429949.000000           434220.000000    -1.546810   
    75%             432186.000000           436193.000000    -1.512829   
    max             446816.000000           449678.000000    -1.291284   
    
               latitude    police_force accident_severity  number_of_vehicles  \
    count   6900.000000            6900              6900         6900.000000   
    unique          NaN               1                 3                 NaN   
    top             NaN  West Yorkshire            Slight                 NaN   
    freq            NaN            6900              5052                 NaN   
    mean      53.804044             NaN               NaN            1.836667   
    std        0.040456             NaN               NaN            0.714998   
    min       53.704028             NaN               NaN            1.000000   
    25%       53.782254             NaN               NaN            1.000000   
    50%       53.803458             NaN               NaN            2.000000   
    75%       53.821061             NaN               NaN            2.000000   
    max       53.941658             NaN               NaN           13.000000   
    
            ...  light_conditions  weather_conditions road_surface_conditions  \
    count   ...              6900                6900                    6900   
    unique  ...                 5                   9                       5   
    top     ...          Daylight  Fine no high winds                     Dry   
    freq    ...              4899                5657                    4932   
    mean    ...               NaN                 NaN                     NaN   
    std     ...               NaN                 NaN                     NaN   
    min     ...               NaN                 NaN                     NaN   
    25%     ...               NaN                 NaN                     NaN   
    50%     ...               NaN                 NaN                     NaN   
    75%     ...               NaN                 NaN                     NaN   
    max     ...               NaN                 NaN                     NaN   
    
           special_conditions_at_site   carriageway_hazards urban_or_rural_area  \
    count                         165                   150                6900   
    unique                          9                     7                   2   
    top                     Roadworks  Other object on road               Urban   
    freq                          100                    85                5707   
    mean                          NaN                   NaN                 NaN   
    std                           NaN                   NaN                 NaN   
    min                           NaN                   NaN                 NaN   
    25%                           NaN                   NaN                 NaN   
    50%                           NaN                   NaN                 NaN   
    75%                           NaN                   NaN                 NaN   
    max                           NaN                   NaN                 NaN   
    
           did_police_officer_attend_scene_of_accident trunk_road_flag  \
    count                                         6900            6900   
    unique                                           3               2   
    top                                            Yes       Non-trunk   
    freq                                          5181            6360   
    mean                                           NaN             NaN   
    std                                            NaN             NaN   
    min                                            NaN             NaN   
    25%                                            NaN             NaN   
    50%                                            NaN             NaN   
    75%                                            NaN             NaN   
    max                                            NaN             NaN   
    
           lsoa_of_accident_location enhanced_severity_collision  
    count                       6900                 6900.000000  
    unique                       469                         NaN  
    top                    E01033010                         NaN  
    freq                         189                         NaN  
    mean                         NaN                    2.077971  
    std                          NaN                    2.761004  
    min                          NaN                   -1.000000  
    25%                          NaN                   -1.000000  
    50%                          NaN                    3.000000  
    75%                          NaN                    3.000000  
    max                          NaN                    7.000000  
    
    [11 rows x 37 columns] 
    
    Leeds Vehicle Summary Stats:
           accident_index  accident_year accident_reference  vehicle_reference  \
    count           12673   12673.000000              12673       12673.000000   
    unique           6900            NaN               6900                NaN   
    top     2023131286994            NaN          131286994                NaN   
    freq               13            NaN                 13                NaN   
    mean              NaN    2021.086720                NaN           1.558037   
    std               NaN       1.439206                NaN           0.746497   
    min               NaN    2019.000000                NaN           1.000000   
    25%               NaN    2020.000000                NaN           1.000000   
    50%               NaN    2021.000000                NaN           1.000000   
    75%               NaN    2022.000000                NaN           2.000000   
    max               NaN    2023.000000                NaN          13.000000   
    
           vehicle_type towing_and_articulation  vehicle_manoeuvre  \
    count         12673                   12673              12673   
    unique           19                       7                 19   
    top             Car     No tow/articulation  Going ahead other   
    freq           9228                   12587               6775   
    mean            NaN                     NaN                NaN   
    std             NaN                     NaN                NaN   
    min             NaN                     NaN                NaN   
    25%             NaN                     NaN                NaN   
    50%             NaN                     NaN                NaN   
    75%             NaN                     NaN                NaN   
    max             NaN                     NaN                NaN   
    
           vehicle_direction_from vehicle_direction_to  \
    count                   12673                12673   
    unique                     10                   10   
    top                     North                North   
    freq                     2324                 2407   
    mean                      NaN                  NaN   
    std                       NaN                  NaN   
    min                       NaN                  NaN   
    25%                       NaN                  NaN   
    50%                       NaN                  NaN   
    75%                       NaN                  NaN   
    max                       NaN                  NaN   
    
                  vehicle_location_restricted_lane  ... generic_make_model  \
    count                                    12673  ...                  0   
    unique                                      11  ...                  0   
    top     On main c'way - not in restricted lane  ...                NaN   
    freq                                     11528  ...                NaN   
    mean                                       NaN  ...                NaN   
    std                                        NaN  ...                NaN   
    min                                        NaN  ...                NaN   
    25%                                        NaN  ...                NaN   
    50%                                        NaN  ...                NaN   
    75%                                        NaN  ...                NaN   
    max                                        NaN  ...                NaN   
    
            driver_imd_decile driver_home_area_type lsoa_of_driver  \
    count               12673                 12673          12673   
    unique                 11                     4           2118   
    top     Most deprived 10%            Urban area             -1   
    freq                 2853                  9235           2579   
    mean                  NaN                   NaN            NaN   
    std                   NaN                   NaN            NaN   
    min                   NaN                   NaN            NaN   
    25%                   NaN                   NaN            NaN   
    50%                   NaN                   NaN            NaN   
    75%                   NaN                   NaN            NaN   
    max                   NaN                   NaN            NaN   
    
                           escooter_flag dir_from_e dir_from_n dir_to_e dir_to_n  \
    count                          12673        0.0        0.0      0.0      0.0   
    unique                             2        NaN        NaN      NaN      NaN   
    top     Vehicle was not an e-scooter        NaN        NaN      NaN      NaN   
    freq                           12665        NaN        NaN      NaN      NaN   
    mean                             NaN        NaN        NaN      NaN      NaN   
    std                              NaN        NaN        NaN      NaN      NaN   
    min                              NaN        NaN        NaN      NaN      NaN   
    25%                              NaN        NaN        NaN      NaN      NaN   
    50%                              NaN        NaN        NaN      NaN      NaN   
    75%                              NaN        NaN        NaN      NaN      NaN   
    max                              NaN        NaN        NaN      NaN      NaN   
    
                                      driver_distance_banding  
    count                                               10164  
    unique                                                  5  
    top     Collision occurred within 5km of drivers home ...  
    freq                                                 5542  
    mean                                                  NaN  
    std                                                   NaN  
    min                                                   NaN  
    25%                                                   NaN  
    50%                                                   NaN  
    75%                                                   NaN  
    max                                                   NaN  
    
    [11 rows x 34 columns] 
    
    Leeds Casualty Summary Stats:
           accident_index  accident_year accident_reference  vehicle_reference  \
    count            8883    8883.000000               8883        8883.000000   
    unique           6900            NaN               6900                NaN   
    top     20191369T0667            NaN          1369T0667                NaN   
    freq               13            NaN                 13                NaN   
    mean              NaN    2021.083643                NaN           1.528538   
    std               NaN       1.440435                NaN           0.605417   
    min               NaN    2019.000000                NaN           1.000000   
    25%               NaN    2020.000000                NaN           1.000000   
    50%               NaN    2021.000000                NaN           1.000000   
    75%               NaN    2022.000000                NaN           2.000000   
    max               NaN    2023.000000                NaN           8.000000   
    
            casualty_reference   casualty_class sex_of_casualty  \
    count          8883.000000             8883            8883   
    unique                 NaN                3               3   
    top                    NaN  Driver or rider            Male   
    freq                   NaN             5417            5502   
    mean              1.346617              NaN             NaN   
    std               0.814870              NaN             NaN   
    min               1.000000              NaN             NaN   
    25%               1.000000              NaN             NaN   
    50%               1.000000              NaN             NaN   
    75%               1.000000              NaN             NaN   
    max              13.000000              NaN             NaN   
    
                         age_of_casualty age_band_of_casualty casualty_severity  \
    count                             23                 8883              8883   
    unique                             1                   12                 3   
    top     Data missing or out of range              26 - 35            Slight   
    freq                              23                 1971              6841   
    mean                             NaN                  NaN               NaN   
    std                              NaN                  NaN               NaN   
    min                              NaN                  NaN               NaN   
    25%                              NaN                  NaN               NaN   
    50%                              NaN                  NaN               NaN   
    75%                              NaN                  NaN               NaN   
    max                              NaN                  NaN               NaN   
    
            ... pedestrian_movement      car_passenger  \
    count   ...                8883               8883   
    unique  ...                  10                  4   
    top     ...    Not a Pedestrian  Not car passenger   
    freq    ...                7368               7248   
    mean    ...                 NaN                NaN   
    std     ...                 NaN                NaN   
    min     ...                 NaN                NaN   
    25%     ...                 NaN                NaN   
    50%     ...                 NaN                NaN   
    75%     ...                 NaN                NaN   
    max     ...                 NaN                NaN   
    
                  bus_or_coach_passenger pedestrian_road_maintenance_worker  \
    count                           8883                               8883   
    unique                             6                                  4   
    top     Not a bus or coach passenger                No / Not applicable   
    freq                            8747                               7930   
    mean                             NaN                                NaN   
    std                              NaN                                NaN   
    min                              NaN                                NaN   
    25%                              NaN                                NaN   
    50%                              NaN                                NaN   
    75%                              NaN                                NaN   
    max                              NaN                                NaN   
    
           casualty_type casualty_home_area_type casualty_imd_decile  \
    count           8883                    8883                8883   
    unique            19                       4                  11   
    top     Car occupant              Urban area   Most deprived 10%   
    freq            4982                    7810                2623   
    mean             NaN                     NaN                 NaN   
    std              NaN                     NaN                 NaN   
    min              NaN                     NaN                 NaN   
    25%              NaN                     NaN                 NaN   
    50%              NaN                     NaN                 NaN   
    75%              NaN                     NaN                 NaN   
    max              NaN                     NaN                 NaN   
    
           lsoa_of_casualty enhanced_casualty_severity  \
    count              8883                       8883   
    unique             1651                          6   
    top                  -1                     Slight   
    freq                449                       4070   
    mean                NaN                        NaN   
    std                 NaN                        NaN   
    min                 NaN                        NaN   
    25%                 NaN                        NaN   
    50%                 NaN                        NaN   
    75%                 NaN                        NaN   
    max                 NaN                        NaN   
    
                                    casualty_distance_banding  
    count                                                8883  
    unique                                                  6  
    top     Collision occurred within 5km of casualties ho...  
    freq                                                 5174  
    mean                                                  NaN  
    std                                                   NaN  
    min                                                   NaN  
    25%                                                   NaN  
    50%                                                   NaN  
    75%                                                   NaN  
    max                                                   NaN  
    
    [11 rows x 21 columns] 
    
    

.. code:: ipython3

    # Cleaning look_up leeds data
    import pandas as pd
    import numpy as np
    
    # base_path directory
    base_path = r"C:\Users\mayth\OneDrive - Leeds Beckett University\MS Data Science Modules\Dissertation\RTA Dataset\\"
    
    # files after look up
    collision_file = base_path + "leeds_collision_after_lookup.csv"
    vehicle_file = base_path + "leeds_vehicle_after_lookup.csv"
    casualty_file = base_path + "leeds_casualty_after_lookup.csv"
    
    # load the data
    collision_df = pd.read_csv(collision_file, low_memory=False)
    vehicle_df = pd.read_csv(vehicle_file, low_memory=False)
    casualty_df = pd.read_csv(casualty_file, low_memory=False)
    
    # --- Clean Collision Data ---
    
    # drop unused or mostly empty columns
    collision_df.drop(columns=[
        'speed_limit', 
        'carriageway_hazards', 
        'special_conditions_at_site'
    ], errors='ignore', inplace=True)
    
    # replace -1 with NaN (if still present)
    collision_df['enhanced_severity_collision'] = collision_df['enhanced_severity_collision'].replace(-1, np.nan)
    
    # convert 'date' to datetime
    collision_df['date'] = pd.to_datetime(collision_df['date'], errors='coerce', dayfirst=True)
    
    # extract hour from 'time'
    collision_df['hour'] = pd.to_datetime(collision_df['time'], format='%H:%M', errors='coerce').dt.hour
    
    # save cleaned collision file
    collision_df.to_csv(base_path + "leeds_collision_final.csv", index=False)
    
    # --- Clean Vehicle Data ---
    
    # drop irrelevant or mostly missing columns
    vehicle_df.drop(columns=[
        'dir_to_n', 'dir_to_e', 'dir_from_n', 'dir_from_e',
        'generic_make_model', 'engine_capacity_cc', 'age_of_driver',
        'skidding_and_overturning', 'hit_object_in_carriageway', 'hit_object_off_carriageway'
    ], errors='ignore', inplace=True)
    
    # save cleaned vehicle file
    vehicle_df.to_csv(base_path + "leeds_vehicle_final.csv", index=False)
    
    # --- Clean Casualty Data ---
    
    # drop column if mostly null
    casualty_df.drop(columns=['age_of_casualty'], errors='ignore', inplace=True)
    
    # Fix misinterpreted age bands due to date formatting
    casualty_df['age_band_of_casualty'] = casualty_df['age_band_of_casualty'].replace({
        '06-Oct': '6 - 10',
        'Nov-15': '11 - 15'
    })
    
    # save cleaned casualty file
    casualty_df.to_csv(base_path + "leeds_casualty_final.csv", index=False)
    
    # successful message
    print("Cleaned datasets saved")
    


.. parsed-literal::

    Cleaned datasets saved
    

.. code:: ipython3

    # load the cleaned files
    collision_final = pd.read_csv(base_path + "leeds_collision_final.csv", low_memory=False)
    vehicle_final = pd.read_csv(base_path + "leeds_vehicle_final.csv", low_memory=False)
    casualty_final = pd.read_csv(base_path + "leeds_casualty_final.csv", low_memory=False)
    
    # Print the shape (rows, columns)
    print("leeds_collision_final.csv shape:", collision_final.shape)
    print("leeds_vehicle_final.csv shape:", vehicle_final.shape)
    print("leeds_casualty_final.csv shape:", casualty_final.shape)
    


.. parsed-literal::

    leeds_collision_final.csv shape: (6900, 35)
    leeds_vehicle_final.csv shape: (12673, 24)
    leeds_casualty_final.csv shape: (8883, 20)
    

.. code:: ipython3

    # For EDA
    # Load Libraries & Data
    
    import pandas as pd
    import matplotlib.pyplot as plt
    import seaborn as sns
    
    # Styling
    sns.set(style="whitegrid")
    plt.rcParams["figure.figsize"] = (10, 5)
    
    # Load cleaned final datasets
    base_path = r"C:\Users\mayth\OneDrive - Leeds Beckett University\MS Data Science Modules\Dissertation\RTA Dataset\\"
    
    collision_df = pd.read_csv(base_path + "leeds_collision_final.csv")
    vehicle_df = pd.read_csv(base_path + "leeds_vehicle_final.csv")
    casualty_df = pd.read_csv(base_path + "leeds_casualty_final.csv")
    

.. code:: ipython3

    # EDA
    # Number of Accidents in Leeds by Year (Bar Chart)
    
    collision_df['date'] = pd.to_datetime(collision_df['date'], errors='coerce')
    collision_df['year'] = collision_df['date'].dt.year
    
    sns.countplot(data=collision_df, x='year', palette='Blues_d')
    plt.title("Number of Accidents in Leeds by Year")
    plt.xlabel("Year")
    plt.ylabel("Accident Count")
    plt.tight_layout()
    plt.show()
    


.. parsed-literal::

    C:\Users\mayth\AppData\Local\Temp\ipykernel_12428\3418069932.py:5: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.countplot(data=collision_df, x='year', palette='Blues_d')
    


.. image:: output_7_1.png


.. code:: ipython3

    # EDA
    # Monthly Trend of Accidents Over Time
    
    collision_df['month'] = collision_df['date'].dt.to_period('M')
    
    # Count number of accidents per month
    monthly_trend = collision_df.groupby('month').size().reset_index(name='accidents')
    monthly_trend['month'] = monthly_trend['month'].astype(str)
    
    plt.figure(figsize=(14, 5))
    sns.lineplot(data=monthly_trend, x='month', y='accidents', marker='o')
    plt.xticks(rotation=45)
    plt.title("Monthly Trend of Accidents Over Time")
    plt.xlabel("Month")
    plt.ylabel("Number of Accidents")
    plt.tight_layout()
    plt.show()
    



.. image:: output_8_0.png


.. code:: ipython3

    # EDA
    # Casualties by Age Band
    
    plot_df = full_df[full_df['age_band_of_casualty'] != 'Data missing or out of range']
    
    sns.countplot(data=plot_df, x='age_band_of_casualty', order=plot_df['age_band_of_casualty'].value_counts().index, palette='muted')
    plt.title("Casualties by Age Band in Leeds")
    plt.xlabel("Age Band")
    plt.ylabel("Number of Casualties")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()


.. parsed-literal::

    C:\Users\mayth\AppData\Local\Temp\ipykernel_12428\3108744384.py:6: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.countplot(data=plot_df, x='age_band_of_casualty', order=plot_df['age_band_of_casualty'].value_counts().index, palette='muted')
    


.. image:: output_9_1.png


.. code:: ipython3

    # EDA
    # Vehicle Types Involved in Accidents (Top 10)
    
    top_vehicles = vehicle_df['vehicle_type'].value_counts().nlargest(10)
    
    sns.barplot(x=top_vehicles.values, y=top_vehicles.index, palette='Set2')
    plt.title("Top 10 Vehicle Types Involved in Leeds Accidents")
    plt.xlabel("Number of Vehicles")
    plt.ylabel("Vehicle Type")
    plt.tight_layout()
    plt.show()
    


.. parsed-literal::

    C:\Users\mayth\AppData\Local\Temp\ipykernel_12428\2578952270.py:6: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x=top_vehicles.values, y=top_vehicles.index, palette='Set2')
    


.. image:: output_10_1.png


.. code:: ipython3

    # EDA
    # Accident Severity Distribution in Leeds
    
    sns.countplot(data=collision_df, x='accident_severity', order=collision_df['accident_severity'].value_counts().index, palette='coolwarm')
    plt.title("Accident Severity Distribution in Leeds")
    plt.xlabel("Severity")
    plt.ylabel("Number of Accidents")
    plt.tight_layout()
    plt.show()
    


.. parsed-literal::

    C:\Users\mayth\AppData\Local\Temp\ipykernel_12428\3302240915.py:4: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.countplot(data=collision_df, x='accident_severity', order=collision_df['accident_severity'].value_counts().index, palette='coolwarm')
    


.. image:: output_11_1.png


.. code:: ipython3

    # EDA
    # Count casualties by sex
    sex_counts = full_df[full_df['sex_of_casualty'] != 'Data missing or out of range']['sex_of_casualty'].value_counts()
    
    plt.figure(figsize=(6, 6))
    plt.pie(sex_counts, labels=sex_counts.index, autopct='%1.1f%%', startangle=140, colors=sns.color_palette('pastel'))
    plt.title("Proportion of Casualties by Sex")
    plt.axis('equal')  # Equal aspect ratio ensures a circle
    plt.show()
    



.. image:: output_12_0.png


.. code:: ipython3

    # EDA
    # Accident Locations in Leeds (Scatter Plot)
    
    # Drop rows with missing coordinates
    map_data = collision_df.dropna(subset=['latitude', 'longitude'])
    
    # Plot points
    plt.figure(figsize=(10, 6))
    sns.scatterplot(data=map_data, x='longitude', y='latitude', alpha=0.3, s=10)
    plt.title("Accident Locations in Leeds (Scatter Plot)")
    plt.xlabel("Longitude")
    plt.ylabel("Latitude")
    plt.tight_layout()
    plt.show()
    



.. image:: output_13_0.png


.. code:: ipython3

    # EDA
    # Accident Locations in Leeds by Year
    
    import seaborn as sns
    import matplotlib.pyplot as plt
    
    # Make sure 'year' column exists and is of type int or str
    map_data['year'] = map_data['date'].dt.year
    
    # Create FacetGrid
    g = sns.FacetGrid(map_data, col='year', col_wrap=3, height=4)
    g.map_dataframe(sns.scatterplot, x='longitude', y='latitude', alpha=0.3, s=10)
    g.set_titles("Year: {col_name}")
    g.set_axis_labels("Longitude", "Latitude")
    plt.tight_layout()
    plt.show()
    



.. image:: output_14_0.png


.. code:: ipython3

    # EDA
    # Accident Severity by Hour of Day
    
    collision_df['hour'] = pd.to_datetime(collision_df['time'], format='%H:%M', errors='coerce').dt.hour
    
    plt.figure(figsize=(12, 6))
    sns.countplot(data=collision_df, x='hour', hue='accident_severity', palette='Set2')
    plt.title("Accident Severity by Hour of Day")
    plt.xlabel("Hour of Day")
    plt.ylabel("Number of Accidents")
    plt.legend(title="Severity")
    plt.tight_layout()
    plt.show()
    



.. image:: output_15_0.png


.. code:: ipython3

    # EDA
    # Accident Severity by Day of Week
    
    collision_df['date'] = pd.to_datetime(collision_df['date'], errors='coerce')
    
    collision_df['weekday'] = collision_df['date'].dt.day_name()
    weekday_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    
    severity_palette = {
        'Fatal': '#d73027',    # deep red
        'Serious': '#fc8d59',  # orange
        'Slight': '#fee08b'    # light yellow
    }
    
    plt.figure(figsize=(12, 6))
    sns.countplot(data=collision_df, x='weekday', hue='accident_severity', order=weekday_order, palette=severity_palette)
    plt.title("Accident Severity by Day of the Week")
    plt.xlabel("Day of Week")
    plt.ylabel("Number of Accidents")
    plt.legend(title="Severity")
    plt.tight_layout()
    plt.show()
    



.. image:: output_16_0.png


.. code:: ipython3

    # EDA
    # Casualty Class by Age Band
    
    plot_df = full_df[full_df['age_band_of_casualty'] != 'Data missing or out of range']
    
    plt.figure(figsize=(12, 6))
    sns.countplot(data=plot_df, x='age_band_of_casualty', hue='casualty_class', order=plot_df['age_band_of_casualty'].value_counts().index)
    plt.title("Casualty Class by Age Band")
    plt.xlabel("Age Band")
    plt.ylabel("Number of Casualties")
    plt.legend(title="Casualty Class")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()
    



.. image:: output_17_0.png


.. code:: ipython3

    # Merge accident data with open meteo weather dataset
    
    import pandas as pd
    
    # base_path
    base_path = r"C:\Users\mayth\OneDrive - Leeds Beckett University\MS Data Science Modules\Dissertation\RTA Dataset\\"
    
    # load the Leeds collision dataset
    collision_df = pd.read_csv(base_path + "leeds_collision_final.csv", low_memory=False)
    
    # load the weather dataset (gonna skip first description row)
    weather_df = pd.read_csv(base_path + "weather dataset_open-meteo-53.81N1.56W48m.csv", skiprows=1)
    
    # rename weather columns for easier access
    weather_df.columns = [
        'time', 'temperature', 'dew_point', 'apparent_temp',
        'precipitation', 'rain', 'snowfall', 'snow_depth',
        'wind_speed', 'weather_code', 'sunshine_duration', 'is_day'
    ]
    
    # convert 'time' in weather to datetime
    weather_df['time'] = pd.to_datetime(weather_df['time'], errors='coerce')
    
    # extract date and hour from weather data
    weather_df['date'] = weather_df['time'].dt.date
    weather_df['hour'] = weather_df['time'].dt.hour
    
    # remove any weather rows with invalid time
    weather_df.dropna(subset=['time'], inplace=True)
    
    # convert collision date to datetime and extract date
    collision_df['date'] = pd.to_datetime(collision_df['date'], errors='coerce').dt.date
    
    # ensure 'hour' is numeric in collision data
    collision_df['hour'] = pd.to_numeric(collision_df['hour'], errors='coerce')
    
    # merge collision and weather data on 'date' and 'hour'
    merged_df = pd.merge(collision_df, weather_df, on=['date', 'hour'], how='left')
    
    # save the merged dataset
    merged_df.to_csv(base_path + "leeds_collision_with_weather.csv", index=False)
    
    print("Merged dataset saved as leeds_collision_with_weather.csv")
    


.. parsed-literal::

    Merged dataset saved as leeds_collision_with_weather.csv
    

.. code:: ipython3

    # EDA
    # Scatterplot of Daily Rainfall vs. Accidents
    
    import pandas as pd
    import matplotlib.pyplot as plt
    import seaborn as sns
    
    # Make sure 'date' is in datetime format
    merged_df['date'] = pd.to_datetime(merged_df['date'], errors='coerce')
    
    # Group by date to get total accidents and average rain per day
    daily_summary = merged_df.groupby('date').agg({
        'accident_index': 'count',
        'rain': 'mean'
    }).reset_index()
    
    # Rename columns for clarity
    daily_summary.rename(columns={'accident_index': 'num_accidents'}, inplace=True)
    
    # Plot
    plt.figure(figsize=(10, 6))
    sns.scatterplot(data=daily_summary, x='rain', y='num_accidents', alpha=0.6)
    plt.title("Scatterplot: Daily Rainfall vs. Number of Accidents in Leeds")
    plt.xlabel("Rainfall (mm)")
    plt.ylabel("Number of Accidents")
    plt.grid(True)
    plt.tight_layout()
    plt.show()
    



.. image:: output_19_0.png


.. code:: ipython3

    import pandas as pd
    import seaborn as sns
    import matplotlib.pyplot as plt
    
    # to make sure sunshine_duration and relevant weather columns are numeric
    merged_df['sunshine_duration'] = pd.to_numeric(merged_df['sunshine_duration'], errors='coerce')
    
    # 1. Bin Sunshine Duration
    # Convert from seconds to minute
    merged_df['sunshine_minutes'] = merged_df['sunshine_duration'] / 60
    
    # Create sunshine bands
    merged_df['sun_band'] = pd.cut(
        merged_df['sunshine_duration'],
        bins=[-1, 0, 1200, 2400, 3600],
        labels=['No Sun', 'Low Sun (0–20 min)', 'Moderate Sun (20–40 min)', 'Full Sun (60 min)'],
        include_lowest=True
    )
    
    # 2. Visualize Accidents by Sunshine Band
    plt.figure(figsize=(8, 5))
    sns.countplot(data=merged_df, x='sun_band', palette='Pastel1')
    plt.title("Accidents by Sunshine Duration Band")
    plt.xlabel("Sunshine Duration per Hour")
    plt.ylabel("Number of Accidents")
    plt.tight_layout()
    plt.show()
    
    


.. parsed-literal::

    C:\Users\mayth\AppData\Local\Temp\ipykernel_12428\2277197189.py:22: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.countplot(data=merged_df, x='sun_band', palette='Pastel1')
    


.. image:: output_20_1.png


.. code:: ipython3

    import pandas as pd
    import glob
    import os
    
    # data_dir
    data_dir = r"C:\Users\mayth\OneDrive - Leeds Beckett University\MS Data Science Modules\Dissertation\RTA Dataset"
    
    # Load all relevant CSVs
    e0_files = sorted(glob.glob(os.path.join(data_dir, "E0*.csv")))
    e1_files = sorted(glob.glob(os.path.join(data_dir, "E1*.csv")))
    
    df_e0_all = pd.concat([pd.read_csv(f) for f in e0_files], ignore_index=True)
    df_e1_all = pd.concat([pd.read_csv(f) for f in e1_files], ignore_index=True)
    
    # Combine and Filter by Year
    df_all = pd.concat([df_e0_all, df_e1_all], ignore_index=True)
    df_all['Date'] = pd.to_datetime(df_all['Date'], errors='coerce', dayfirst=True)
    df_all = df_all[df_all['Date'].dt.year.between(2019, 2023)]
    
    # Leeds United Home Matches
    df_leeds = df_all[df_all['HomeTeam'] == "Leeds"].copy()
    
    # Remove 2019 Leeds matches with missing Time
    df_leeds = df_leeds[~((df_leeds['Date'].dt.year == 2019) & (df_leeds['Time'].isna()))]
    
    # Add Stadium Location
    df_leeds["Stadium"] = "Elland Road"
    df_leeds["City"] = "Leeds"
    df_leeds["Latitude"] = 53.7775
    df_leeds["Longitude"] = -1.5722
    
    # STEP 6: Combine Date and Time
    df_leeds["MatchDateTime"] = pd.to_datetime(
        df_leeds["Date"].astype(str) + " " + df_leeds["Time"].astype(str),
        errors='coerce'
    )
    
    # Select Columns and Save
    final_df = df_leeds[[ 
        "Date", "Time", "MatchDateTime", "HomeTeam", "AwayTeam", "FTHG", "FTAG", "FTR",
        "Stadium", "City", "Latitude", "Longitude"
    ]]
    
    # Save the output
    output_path = os.path.join(data_dir, "leeds_home_matches_2019_2023.csv")
    final_df.to_csv(output_path, index=False)
    
    print(f"Saved: {output_path}")
    


.. parsed-literal::

    Saved: C:\Users\mayth\OneDrive - Leeds Beckett University\MS Data Science Modules\Dissertation\RTA Dataset\leeds_home_matches_2019_2023.csv
    

.. code:: ipython3

    import pandas as pd
    from geopy.distance import geodesic
    import os
    
    # === Base path where all files are stored ===
    base_path = r"C:\Users\mayth\OneDrive - Leeds Beckett University\MS Data Science Modules\Dissertation\RTA Dataset\\"
    
    # file paths
    matches_path = os.path.join(base_path, "leeds_home_matches_2019_2023.csv")
    accidents_path = os.path.join(base_path, "leeds_collision_final.csv")
    output_path = os.path.join(base_path, "linked_accidents_near_elland_road.csv")
    
    # === Load datasets ===
    df_matches = pd.read_csv(matches_path)
    df_accidents = pd.read_csv(accidents_path)
    
    # === Parse datetime columns ===
    df_matches["MatchDateTime"] = pd.to_datetime(df_matches["MatchDateTime"], errors='coerce')
    df_accidents["accident_datetime"] = pd.to_datetime(df_accidents["date"] + " " + df_accidents["time"], errors='coerce')
    
    # === Function: Match proximity and time window ===
    def is_near_match(accident_row, match_df, max_km=1, time_window_hours=3):
        acc_coords = (accident_row["latitude"], accident_row["longitude"])
        acc_time = accident_row["accident_datetime"]
    
        for _, match in match_df.iterrows():
            match_coords = (match["Latitude"], match["Longitude"])
            match_time = match["MatchDateTime"]
    
            # Check distance and time
            if geodesic(acc_coords, match_coords).km <= max_km:
                if pd.notnull(acc_time) and abs((acc_time - match_time).total_seconds()) <= time_window_hours * 3600:
                    return True
        return False
    
    # === Apply linking logic ===
    df_accidents["Match_Day_Near_Stadium"] = df_accidents.apply(
        lambda row: is_near_match(row, df_matches), axis=1
    )
    
    # === Filter and save linked accidents ===
    linked_accidents = df_accidents[df_accidents["Match_Day_Near_Stadium"] == True]
    linked_accidents.to_csv(output_path, index=False)
    
    print(f"✅ Linked accident data saved at: {output_path}")
    


::


    ---------------------------------------------------------------------------

    ModuleNotFoundError                       Traceback (most recent call last)

    Cell In[111], line 2
          1 import pandas as pd
    ----> 2 from geopy.distance import geodesic
          3 import os
          5 # === Base path where all files are stored ===
    

    ModuleNotFoundError: No module named 'geopy'


